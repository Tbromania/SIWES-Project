This is all i have. I don't have any notes all of em are in my logs which i got 50% from you.
